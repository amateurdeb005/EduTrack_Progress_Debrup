/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edutrackapp.progress;

/**
 *
 * @author dhali
 */
public class Main {
    public static void main(String[] args) {
        new ProgressForm("Testing for Student", new ProgressTracker()).setVisible(true);
    }
}

